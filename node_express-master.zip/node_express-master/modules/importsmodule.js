var mdl = require("./utilitymodule");
console.log(mdl.getStringLenght("Mahesh"));
console.log(mdl.changeCase("Mahesh"));
