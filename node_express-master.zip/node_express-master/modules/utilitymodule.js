module.exports = {
  getStringLenght: function(str) {
    return str.length;
  },
  changeCase: function(str) {
    return str.toUpperCase();
  }
};
